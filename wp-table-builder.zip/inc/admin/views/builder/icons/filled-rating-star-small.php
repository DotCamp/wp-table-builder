<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 426.667 426.667" style="enable-background:new 0 0 426.667 426.667;" xml:space="preserve">
		<polygon points="426.667,165.12 273.28,152.107 213.333,10.667 153.387,152.107 0,165.12 116.48,266.027 81.493,416 
			213.333,336.427 345.173,416 310.187,266.027 		"/>
</svg>
